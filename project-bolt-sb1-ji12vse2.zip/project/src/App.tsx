import React, { useState } from 'react';
import { 
  Thermometer, 
  Wind, 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  Calendar,
  AlertTriangle,
  CheckCircle,
  Lightbulb,
  Shield,
  Settings,
  Smartphone,
  Cloud,
  Activity,
  BarChart3,
  Clock,
  User,
  Home,
  Zap,
  Heart
} from 'lucide-react';

function App() {
  const [activeSection, setActiveSection] = useState('overview');

  const sections = [
    { id: 'overview', name: 'Overview', icon: Home },
    { id: 'scope', name: 'Product Scope', icon: Target },
    { id: 'journey', name: 'User Journey', icon: Users },
    { id: 'technical', name: 'Technical', icon: Settings },
    { id: 'metrics', name: 'Success Metrics', icon: BarChart3 },
    { id: 'roadmap', name: 'Roadmap', icon: Calendar },
    { id: 'risks', name: 'Risk Management', icon: AlertTriangle }
  ];

  const features = [
    {
      title: 'Condition-Specific Presets',
      description: 'Auto-sets room parameters based on disclosed health needs',
      benefit: 'Eliminates manual adjustments',
      icon: Heart,
      color: 'bg-red-500'
    },
    {
      title: 'Real-Time Air Quality Control',
      description: 'AI detects PM2.5/VOCs; triggers purifiers or ventilation',
      benefit: 'Reduces respiratory triggers',
      icon: Wind,
      color: 'bg-blue-500'
    },
    {
      title: 'Migraine Mode',
      description: 'Dims lights, activates noise-canceling, sets optimal humidity',
      benefit: 'Prevents headache exacerbation',
      icon: Brain,
      color: 'bg-purple-500'
    },
    {
      title: 'Guest Override Options',
      description: 'Manual controls via app/voice commands',
      benefit: 'Balances automation with personal choice',
      icon: Smartphone,
      color: 'bg-green-500'
    },
    {
      title: 'Energy Efficiency Reports',
      description: 'Tracks HVAC optimization savings for sustainability',
      benefit: 'Lowers operational costs',
      icon: Zap,
      color: 'bg-yellow-500'
    }
  ];

  const metrics = [
    { name: 'Guest Comfort Score', value: '4.5/5', target: '4.5/5', progress: 100, color: 'bg-green-500' },
    { name: 'Energy Savings', value: '23%', target: '25%', progress: 92, color: 'bg-blue-500' },
    { name: 'Device Reliability', value: '99.9%', target: '99.9%', progress: 100, color: 'bg-purple-500' },
    { name: 'Guest Satisfaction', value: '4.7/5', target: '4.5/5', progress: 104, color: 'bg-teal-500' }
  ];

  const roadmapPhases = [
    {
      phase: 'Phase 1',
      duration: '4 months',
      title: 'IoT Sensors & Basic Automation',
      description: 'Deploy IoT sensors + basic climate automation in 10 rooms',
      status: 'completed',
      color: 'bg-green-500'
    },
    {
      phase: 'Phase 2', 
      duration: '8 months',
      title: 'AI Integration & Predictive Adjustments',
      description: 'Integrate RL for predictive adjustments (e.g., pre-warm room at 6 AM)',
      status: 'in-progress',
      color: 'bg-blue-500'
    },
    {
      phase: 'Phase 3',
      duration: '12 months', 
      title: 'Voice AI Integration',
      description: 'Voice AI integration ("Adjust room for my arthritis")',
      status: 'planned',
      color: 'bg-gray-400'
    }
  ];

  const risks = [
    {
      risk: 'Over-automation (guests prefer manual control)',
      impact: 'High',
      probability: 'Medium',
      mitigation: 'Opt-in automation + easy override options',
      status: 'mitigated'
    },
    {
      risk: 'Sensor inaccuracies (e.g., false VOC readings)',
      impact: 'Medium',
      probability: 'Low',
      mitigation: 'Multi-sensor validation + quarterly recalibration',
      status: 'monitoring'
    },
    {
      risk: 'Privacy concerns (room occupancy tracking)',
      impact: 'High',
      probability: 'Medium',
      mitigation: 'Explicit consent for motion/voice data collection',
      status: 'addressed'
    }
  ];

  const renderOverview = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Smart Room Environment Control</h1>
        <p className="text-xl text-gray-600 mb-8">AI-Driven IoT System for Health-Optimized Room Automation</p>
        <div className="flex justify-center space-x-4">
          <span className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full font-medium">IoT + AI</span>
          <span className="px-4 py-2 bg-green-100 text-green-800 rounded-full font-medium">Hospitality</span>
          <span className="px-4 py-2 bg-purple-100 text-purple-800 rounded-full font-medium">Health-Optimized</span>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Thermometer className="w-8 h-8 text-red-500" />
            <span className="text-2xl font-bold text-gray-900">24/7</span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Climate Control</h3>
          <p className="text-sm text-gray-600">Automatic temperature and humidity optimization</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Wind className="w-8 h-8 text-blue-500" />
            <span className="text-2xl font-bold text-gray-900">99.9%</span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Air Quality</h3>
          <p className="text-sm text-gray-600">Real-time monitoring and purification</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Brain className="w-8 h-8 text-purple-500" />
            <span className="text-2xl font-bold text-gray-900">AI</span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Predictive</h3>
          <p className="text-sm text-gray-600">Machine learning for personalized comfort</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <Zap className="w-8 h-8 text-yellow-500" />
            <span className="text-2xl font-bold text-gray-900">25%</span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">Energy Savings</h3>
          <p className="text-sm text-gray-600">Reduced operational costs</p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-8 rounded-xl">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Key Objectives</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
            <div>
              <h3 className="font-semibold text-gray-900">Automatically optimize room environments</h3>
              <p className="text-gray-600 text-sm">For guests' health needs and comfort preferences</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
            <div>
              <h3 className="font-semibold text-gray-900">Improve sleep quality</h3>
              <p className="text-gray-600 text-sm">Enhanced guest satisfaction and overall experience</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
            <div>
              <h3 className="font-semibold text-gray-900">Reduce energy waste</h3>
              <p className="text-gray-600 text-sm">Via adaptive climate control and smart optimization</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
            <div>
              <h3 className="font-semibold text-gray-900">Real-time monitoring</h3>
              <p className="text-gray-600 text-sm">Proactive adjustments and preventive measures</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderScope = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Product Scope</h2>
        <p className="text-lg text-gray-600">Core features and functionality overview</p>
      </div>

      <div className="grid gap-6">
        {features.map((feature, index) => {
          const IconComponent = feature.icon;
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-lg ${feature.color}`}>
                  <IconComponent className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 mb-3">{feature.description}</p>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-green-600">Benefit:</span>
                    <span className="text-sm text-gray-700">{feature.benefit}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-red-50 p-6 rounded-xl border border-red-200">
        <h3 className="text-lg font-semibold text-red-800 mb-3 flex items-center">
          <AlertTriangle className="w-5 h-5 mr-2" />
          Out of Scope
        </h3>
        <ul className="space-y-2 text-red-700">
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-red-400 rounded-full"></span>
            <span>Medical-grade air filtration (e.g., HEPA for immunocompromised)</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-red-400 rounded-full"></span>
            <span>Integration with personal medical devices (e.g., CPAP machines)</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-red-400 rounded-full"></span>
            <span>Diagnosing health conditions</span>
          </li>
        </ul>
      </div>
    </div>
  );

  const renderJourney = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">User Journey</h2>
        <p className="text-lg text-gray-600">Guest experience workflow from booking to checkout</p>
      </div>

      <div className="space-y-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <User className="w-6 h-6 mr-2 text-blue-500" />
            Pre-Check-In
          </h3>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-semibold text-sm">1</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">Guest selects health preferences during booking</p>
                <p className="text-sm text-gray-600">Example: "I have asthma" → "Enable air quality monitoring"</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-semibold text-sm">2</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">Room pre-configures automatically</p>
                <p className="text-sm text-gray-600">Sets to 22°C, 45% humidity, and activates air purifier</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <Activity className="w-6 h-6 mr-2 text-green-500" />
            During Stay
          </h3>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <span className="text-green-600 font-semibold text-sm">1</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">Asthma Trigger Detection</p>
                <p className="text-sm text-gray-600">AI detects rising pollen levels → purifier fan speed increases automatically</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <span className="text-green-600 font-semibold text-sm">2</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">Migraine Mode Activation</p>
                <p className="text-sm text-gray-600">Guest says "Hey Hotel, I have a headache" → lights dim to 10%, blackout curtains close</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <CheckCircle className="w-6 h-6 mr-2 text-purple-500" />
            Check-Out
          </h3>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="text-purple-600 font-semibold text-sm">1</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">System resets to baseline</p>
                <p className="text-sm text-gray-600">Room returns to default settings for next guest</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="text-purple-600 font-semibold text-sm">2</span>
              </div>
              <div>
                <p className="font-medium text-gray-900">Data anonymization</p>
                <p className="text-sm text-gray-600">Personal data anonymized; aggregate trends retained for analytics</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTechnical = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Technical Architecture</h2>
        <p className="text-lg text-gray-600">System components and technology stack</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Activity className="w-5 h-5 mr-2 text-blue-500" />
            IoT Sensors
          </h3>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center space-x-2">
              <Thermometer className="w-4 h-4 text-red-500" />
              <span>Temperature (DHT22)</span>
            </li>
            <li className="flex items-center space-x-2">
              <Wind className="w-4 h-4 text-blue-500" />
              <span>Air Quality (Sensirion SPS30)</span>
            </li>
            <li className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-green-500" />
              <span>Noise (Decibel X)</span>
            </li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Brain className="w-5 h-5 mr-2 text-purple-500" />
            AI/ML Models
          </h3>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-purple-500" />
              <span>Reinforcement Learning (HVAC)</span>
            </li>
            <li className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-purple-500" />
              <span>LSTM for predictive adjustments</span>
            </li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Cloud className="w-5 h-5 mr-2 text-blue-500" />
            Backend
          </h3>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center space-x-2">
              <Cloud className="w-4 h-4 text-blue-500" />
              <span>AWS IoT Core</span>
            </li>
            <li className="flex items-center space-x-2">
              <Settings className="w-4 h-4 text-blue-500" />
              <span>Node-RED for device management</span>
            </li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Smartphone className="w-5 h-5 mr-2 text-green-500" />
            Frontend
          </h3>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center space-x-2">
              <Smartphone className="w-4 h-4 text-green-500" />
              <span>React Native (guest app)</span>
            </li>
            <li className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-green-500" />
              <span>Amazon Alexa/Google Home</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="bg-gray-50 p-6 rounded-xl">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Shield className="w-5 h-5 mr-2 text-red-500" />
          Security & Compliance
        </h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-2">Encryption</h4>
            <p className="text-sm text-gray-600">MQTT with TLS for IoT communication</p>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-2">Compliance</h4>
            <p className="text-sm text-gray-600">GDPR, ENERGY STAR certified</p>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-2">Data Retention</h4>
            <p className="text-sm text-gray-600">Anonymize after checkout</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderMetrics = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Success Metrics</h2>
        <p className="text-lg text-gray-600">Key Performance Indicators and targets</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {metrics.map((metric, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">{metric.name}</h3>
              <span className="text-2xl font-bold text-gray-900">{metric.value}</span>
            </div>
            <div className="mb-3">
              <div className="flex justify-between text-sm text-gray-600 mb-1">
                <span>Progress</span>
                <span>Target: {metric.target}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-300 ${metric.color}`}
                  style={{ width: `${Math.min(metric.progress, 100)}%` }}
                ></div>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              {metric.progress >= 100 ? 'Target achieved' : `${metric.progress}% of target`}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderRoadmap = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Development Roadmap</h2>
        <p className="text-lg text-gray-600">Project timeline and milestones</p>
      </div>

      <div className="space-y-6">
        {roadmapPhases.map((phase, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-start space-x-4">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${phase.color}`}>
                <span className="text-white font-semibold">{index + 1}</span>
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-xl font-semibold text-gray-900">{phase.phase}</h3>
                  <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">
                    {phase.duration}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    phase.status === 'completed' ? 'bg-green-100 text-green-800' :
                    phase.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {phase.status === 'completed' ? 'Completed' :
                     phase.status === 'in-progress' ? 'In Progress' : 'Planned'}
                  </span>
                </div>
                <h4 className="text-lg font-medium text-gray-900 mb-2">{phase.title}</h4>
                <p className="text-gray-600">{phase.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderRisks = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Risk Management</h2>
        <p className="text-lg text-gray-600">Identified risks and mitigation strategies</p>
      </div>

      <div className="space-y-4">
        {risks.map((risk, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{risk.risk}</h3>
                <div className="flex items-center space-x-4 mb-3">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-600">Impact:</span>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      risk.impact === 'High' ? 'bg-red-100 text-red-800' :
                      risk.impact === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {risk.impact}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-600">Probability:</span>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      risk.probability === 'High' ? 'bg-red-100 text-red-800' :
                      risk.probability === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {risk.probability}
                    </span>
                  </div>
                </div>
                <p className="text-gray-600 mb-3">{risk.mitigation}</p>
              </div>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                risk.status === 'mitigated' ? 'bg-green-100 text-green-800' :
                risk.status === 'addressed' ? 'bg-blue-100 text-blue-800' :
                'bg-yellow-100 text-yellow-800'
              }`}>
                {risk.status === 'mitigated' ? 'Mitigated' :
                 risk.status === 'addressed' ? 'Addressed' : 'Monitoring'}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'overview': return renderOverview();
      case 'scope': return renderScope();
      case 'journey': return renderJourney();
      case 'technical': return renderTechnical();
      case 'metrics': return renderMetrics();
      case 'roadmap': return renderRoadmap();
      case 'risks': return renderRisks();
      default: return renderOverview();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Home className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Smart Room Control</h1>
                <p className="text-sm text-gray-600">Product Requirements Document</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                Version 1.0
              </span>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                Ready for Development
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Navigation */}
          <nav className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
              <h2 className="text-sm font-semibold text-gray-900 uppercase tracking-wide mb-4">Sections</h2>
              <ul className="space-y-2">
                {sections.map((section) => {
                  const IconComponent = section.icon;
                  return (
                    <li key={section.id}>
                      <button
                        onClick={() => setActiveSection(section.id)}
                        className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                          activeSection === section.id
                            ? 'bg-blue-100 text-blue-700'
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <IconComponent className="w-5 h-5" />
                        <span className="font-medium">{section.name}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          </nav>

          {/* Main Content */}
          <main className="flex-1">
            {renderContent()}
          </main>
        </div>
      </div>
    </div>
  );
}

export default App;